<?php

class BookshelvesTableSeeder extends Seeder {

    public function run()
    {
    	// Uncomment the below to wipe the table clean before populating
    	// DB::table('bookshelves')->delete();

        $bookshelves = array(

        );

        // Uncomment the below to run the seeder
        // DB::table('bookshelves')->insert($bookshelves);
    }

}