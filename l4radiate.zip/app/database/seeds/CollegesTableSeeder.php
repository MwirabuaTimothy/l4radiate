<?php

class CollegesTableSeeder extends Seeder {

    public function run()
    {
    	// Uncomment the below to wipe the table clean before populating
    	// DB::table('colleges')->delete();

        $colleges = array(

        );

        // Uncomment the below to run the seeder
        // DB::table('colleges')->insert($colleges);
    }

}