<?php

class Wishlist extends Eloquent {
    protected $guarded = array();

    public static $rules = array();
}