<?php
header( 'Location: public' ) ;
?>