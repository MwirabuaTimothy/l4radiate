usual git workflow
==================

git add .

git commit -m '{yourname}-{commit count}'  

				eg. git commit -m 'timo-3'

git remote add origin git@github.com:TechyTimo/l4radiate.git
git remote add origin ssh://git@github.com/TechyTimo/l4radiate.git

git push origin master

useful info
===========
git add -A stages All files for pushing via git push origin master

git add . stages new and modified files, without deleted files

git add -u stages modified and deleted files, without new files
git add -A . stage file only under your current path




git and l4


////////////////////////


better layout
css for content space

account view css
profile, user, account relation, eliminate one
studenttable
profile and forums - migrations, seeds
